from account.models import Customer
import products
from django.shortcuts import redirect, render, HttpResponse
from . models import Order, Product, Product_Category
from django.views import View
from products.middlewares.auth import auth_middleware




class Shop(View):

    def post(self, request):
        product = request.POST.get('product')
        remove = request.POST.get('remove')
        cart = request.session.get('cart')        
        if cart:
            quantity = cart.get(product)
            if quantity:
                if remove:
                    if quantity <= 1:
                        cart.pop(product)
                    else:
                        cart[product] = quantity-1
                else:
                    cart[product] = quantity+1
            else:
                cart[product] = 1
        else:
            cart = {}
            cart[product] = 1
        request.session['cart'] = cart
        print('cart', request.session['cart'])
        return redirect('shop')




    def get(self, request):
        cart = request.session.get('cart')
        if not cart:
            request.session['cart'] = {}
        products = None    
        categories = Product_Category.objects.all()
        categoeyID = request.GET.get('category')
        if categoeyID:
            products = Product.get_all_products_by_id(categoeyID)
        else:
            products = Product.objects.all()       
        return render(request, 'shop.html', {'categories':categories,'products':products})

class Cart(View):
    def get(self, request):
        ids = (list(request.session.get('cart').keys('')))
        products = Product.get_products_by_id(ids)
        
        
                  
        return render(request, 'cart.html', {'products':products})

class Checkout(View):
    def post(self, request):
        address = request.POST.get('address')
        mobile = request.POST.get('mobile')
        customer = request.session.get('customer')
        cart = request.session.get('cart')
        products = Product.get_products_by_id(list(cart.keys()))

        for product in products:
            order = Order(customer=Customer(id=customer), product = product, price = product.price, quantity = cart.get(str(product.id)),
                            address=address, mobile=mobile)
            order.save()
        request.session['cart'] = {} 
        return redirect('cart')


class Oreders(View):
    def get(self, request):
        customer = request.session.get('customer')
        orders = Order.get_orders_by_customer(customer)
        return render(request, 'orders.html', {'orders':orders})