from django.http.response import HttpResponse, HttpResponseRedirect
from django.shortcuts import redirect, render
from . models import Customer
from django.contrib.auth.hashers import make_password, check_password
from pages.views import index_view
from django.views import View


def signup_view(request):
    if request.method == 'POST':       
        email = request.POST.get('email')
        password = request.POST.get('password')

        customer = Customer(email=email, password=password)

        error_msg = None
        isExists = customer.isExists()
        if isExists:
            error_msg = 'Email is already taken...'
            return render(request, 'signup.html', {'error_msg':error_msg})
        else:  
            customer.password = make_password(customer.password)
            customer.register()
            redirect(index_view)
        return redirect('Login')
    else:
        return render(request, 'signup.html')


class Login(View):
    return_url = None
    def get(self, request):
        Login.return_url = request.GET.get('return_url')
        return render(request, 'login.html')



    def post(self, request):
        email = request.POST.get('email')
        password = request.POST.get('password')
        
        error_msg_login = None
        customer = Customer.get_customer_by_email(email)
        if customer:
            flag = check_password(password, customer.password)
            if flag:
                request.session['customer'] = customer.id
                request.session['email'] = customer.email
                
                if Login.return_url:
                    return HttpResponseRedirect(Login.return_url)
                else:
                    Login.return_url = None
                    return redirect(index_view)
            else:
                error_msg_login = 'Invalid Credencials...'
                return render(request, 'login.html', {'error_msg_login':error_msg_login})
        else:
            error_msg_login = 'Invaid Credencials...'
            return render(request, 'login.html', {'error_msg_login':error_msg_login})
   


def logout_view(request):
    request.session.clear()
    return redirect(index_view)