from products.middlewares.auth import auth_middleware
from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static
from .views import Checkout, Oreders, Shop, Cart
from django.utils.decorators import method_decorator



urlpatterns = [
    path('shop',Shop.as_view(),name='shop'),
    path('cart',Cart.as_view(),name='cart'),
    path('checkout', Checkout.as_view(),name='checkout'),
    path('orders',auth_middleware(Oreders.as_view()),name='orders'),






    
   
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)