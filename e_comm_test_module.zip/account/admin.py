from account.models import Customer
from django.contrib import admin


admin.site.register(Customer)