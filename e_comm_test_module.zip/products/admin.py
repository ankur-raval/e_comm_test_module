from products.models import Order, Product, Product_Category
from django.contrib import admin


class AdminProduct(admin.ModelAdmin):
    list_display = ['name', 'price', 'category']

class AdminOrder(admin.ModelAdmin):
    list_display = ['id', 'product', 'customer','quantity','price','date']


admin.site.register(Product, AdminProduct)
admin.site.register(Product_Category)
admin.site.register(Order, AdminOrder)

